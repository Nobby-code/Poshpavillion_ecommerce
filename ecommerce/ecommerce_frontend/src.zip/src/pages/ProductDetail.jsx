export default function ProductDetail() {
  return <h2>Product Detail Page</h2>;
}

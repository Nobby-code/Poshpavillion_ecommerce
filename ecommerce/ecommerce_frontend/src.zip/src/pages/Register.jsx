export default function Register() {
  return <h2>Register Page</h2>;
}
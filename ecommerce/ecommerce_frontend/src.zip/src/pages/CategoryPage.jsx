import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

const CategoryPage = () => {
  const { slug } = useParams();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // if (!slug) return;

    // const fetchCategoryProducts = async () => {
    //   try {
    //     const res = await axios.get(
    //       `${
    //         import.meta.env.VITE_API_BASE_URL
    //       }/products/?category__slug=${slug}`
    //     );
    //     setProducts(res.data.results);
    //   } catch (err) {
    //     console.error("Failed to fetch category products", err);
    //   }
    // };

    // fetchCategoryProducts();
    if (slug) {
      //   fetch(`/api/products/?category__slug=${slug}`)
      fetch(
        `${import.meta.env.VITE_API_BASE_URL}/products/?category__slug=${slug}`
      )
        .then((res) => res.json())
        .then((data) => setProducts(data.results || data)) // adapt based on pagination
        .catch((err) => console.error(err));
    }
  }, [slug]);

  return (
    <div className="container">
      <h2>Products in "{slug}" Category</h2>
      <div className="row">
        {products.map((product) => (
          <div className="col-md-3" key={product.id}>
            <div className="card">
              <img
                src={`https://res.cloudinary.com/dxwc7cm3b/${product.image}`}
                alt={product.name}
              />
              <div className="card-body">
                <h5>{product.name}</h5>
                <p>Ksh {product.price}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryPage;
